module github.com/fraudguard-ng/go-service

go 1.22

require (
	github.com/go-redis/redis/v8 v8.11.5
	github.com/gorilla/mux v1.8.1
	github.com/oschwald/geoip2-golang v1.9.0
)

require (
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/oschwald/maxminddb-golang v1.12.0 // indirect
	golang.org/x/sys v0.15.0 // indirect
)
